wie dit leest is dom
